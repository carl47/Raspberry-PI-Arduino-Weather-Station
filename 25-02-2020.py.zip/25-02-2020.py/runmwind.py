from tkinter import*
import mwind as mw
import logging as log

#if first run need to setup folders
mw.first_run()

#load stored data values and display if they exist
log.first_run()

#setup interupts from arduino for IR commands. GPIO17
#setup I2C to allow communication with arduino
mw.setup_pi_interupts()

#setup interupts for arduino data logging. GPIO18
#setup I2C to allow communication RTC & BMP180
log.setup_log_interupts()

#main program loop        
root = Tk()
root.attributes('-fullscreen',True)

#set 8 different frames one on top of each other
mw.set_frames(root)

#set each frame's screen display
mw.set_screens()


root.mainloop()
