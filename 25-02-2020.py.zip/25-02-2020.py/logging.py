import RPi.GPIO as GPIO
import smbus
import SDL_DS3231
from random import randint
import csv
import os
import time
import math

#This is the I2C address we setup in the Arduino Program
arduino_bus = smbus.SMBus(1)
address = 0x04  #I2C arduino address
def writeNumber(value):
 arduino_bus.write_byte(address, value) #send address 0 to 255
 return -1
def readNumber():
 number = arduino_bus.read_byte(address) #get data from I2C address
 return number

#This is the I2C address for the BMP180 sensor
pressure_bus = smbus.SMBus(1)
# BMP180 address, 0x77(119)
##ALTITUDE OF SITE IN METERS
altitude = 40
def sample_pressure():
        # BMP180 address, 0x77(119)
        # Read data back from 0xAA(170), 22 bytes
        data = pressure_bus.read_i2c_block_data(0x77, 0xAA, 22)
        # Convert the data
        AC1 = data[0] * 256 + data[1]
        if AC1 > 32767 :
                AC1 -= 65535
        AC2 = data[2] * 256 + data[3]
        if AC2 > 32767 :
                AC2 -= 65535
        AC3 = data[4] * 256 + data[5]
        if AC3 > 32767 :
                AC3 -= 65535
        AC4 = data[6] * 256 + data[7]
        AC5 = data[8] * 256 + data[9]
        AC6 = data[10] * 256 + data[11]
        B1 = data[12] * 256 + data[13]
        if B1 > 32767 :
                B1 -= 65535
        B2 = data[14] * 256 + data[15]
        if B2 > 32767 :
                B2 -= 65535
        MB = data[16] * 256 + data[17]
        if MB > 32767 :
                MB -= 65535
        MC = data[18] * 256 + data[19]
        if MC > 32767 :
                MC -= 65535
        MD = data[20] * 256 + data[21]
        if MD > 32767 :
                MD -= 65535
        time.sleep(0.005) #  >5ms delay 
        # BMP180 address, 0x77(119)
        # Select measurement control register, 0xF4(244)
        #		0x2E(46)	Enable temperature measurement
        pressure_bus.write_byte_data(0x77, 0xF4, 0x2E)
        time.sleep(0.005) #  >5ms delay 
        # BMP180 address, 0x77(119)
        # Read data back from 0xF6(246), 2 bytes
        # temp MSB, temp LSB
        data = pressure_bus.read_i2c_block_data(0x77, 0xF6, 2)
        # Convert the data
        temp = data[0] * 256 + data[1]
        # BMP180 address, 0x77(119)
        # Select measurement control register, 0xF4(244)
        #		0x74(116)	Enable pressure measurement, OSS = 1
        pressure_bus.write_byte_data(0x77, 0xF4, 0x74)
        time.sleep(0.005) #  >5ms delay 
        # BMP180 address, 0x77(119)
        # Read data back from 0xF6(246), 3 bytes
        # pres MSB1, pres MSB, pres LSB
        data = pressure_bus.read_i2c_block_data(0x77, 0xF6, 3)
        # Convert the data
        pres = ((data[0] * 65536) + (data[1] * 256) + data[2]) / 128
        # Callibration for Temperature
        X1 = (temp - AC6) * AC5 / 32768.0
        X2 = (MC * 2048.0) / (X1 + MD)
        B5 = X1 + X2
        # Calibration for Pressure
        B6 = B5 - 4000
        X1 = (B2 * (B6 * B6 / 4096.0)) / 2048.0
        X2 = AC2 * B6 / 2048.0
        X3 = X1 + X2
        B3 = (((AC1 * 4 + X3) * 2) + 2) / 4.0
        X1 = AC3 * B6 / 8192.0
        X2 = (B1 * (B6 * B6 / 2048.0)) / 65536.0
        X3 = ((X1 + X2) + 2) / 4.0
        B4 = AC4 * (X3 + 32768) / 32768.0
        B7 = ((pres - B3) * (25000.0))
        pressure = 0.0
        if B7 < 2147483648 :
                pressure = (B7 * 2) / B4
        else :
                pressure = (B7 / B4) * 2
        X1 = (pressure / 256.0) * (pressure / 256.0)
        X1 = (X1 * 3038.0) / 65536.0
        X2 = ((-7357) * pressure) / 65536.0
        pressure = (pressure + (X1 + X2 + 3791) / 16.0) / 10
        pnorm = pressure/math.pow((1- altitude/44330),5.255)
        return math.floor(pnorm)

#module access RTC at I2C address 0x68
ds3231= SDL_DS3231.SDL_DS3231(1, 0x68) 
day = ('SUNDAY','MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY')
month = ('JANUARY','FEBURARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST',
         'SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER')    
def show_clock() :
    cc,timeaxis = indoor_displays[0],indoor_displays[8]
    try:
        dt = ds3231.read_all()
        #Return tuple of year, month, date, day, hours, minutes, seconds.
    except : #problem in thread timing ocasional error
        print('ds3231 thread error')
    else:   
        dtm ='{:02}'.format(dt[5])
        dth = dt[4]
        am = 'AM'  #only 12 hour clock
        if(dth > 12):
                am = 'PM'
                dth = dth - 12  #not 24 hour clock
        dth = '{:02}'.format(dth)
        cc.itemconfigure(timeaxis,text = str(dth)+':'+dtm+' '+am+'     '+
                         str(day[dt[3]-1])+' '+str(dt[2])+' '+str(month[dt[1]-1])
                         +' 20'+str(dt[0]))

#called by arduino_log on each data sample received
Inhumidity3day =[] #three days of indoor humidity samples
Intemperature3day =[] #three days of indoor temperature samples  
humidity_conc = [] #gridnumber of humidity concentrated from 2160
temperature_conc = [] #gridnumber of temperature concentrated from 2160
sworking = [] #working list from data to display
def indoor_log(humid,temp) :
    (cc,gridnumber,humidityMax,humidity,humidityMin,temperatureMax,temperature
     ,temperatureMin,timeaxis,sw,sh) = indoor_displays
    Inhumidity3day.append(humid) # add this value
    if len(Inhumidity3day) == 2160 : #have we got a full list
       del Inhumidity3day[0] #delete the first if full
    if len(Inhumidity3day) > 2 : #have we got more than 3
        if Inhumidity3day[len(Inhumidity3day)-1] - Inhumidity3day[len(Inhumidity3day)-2] > 5 :
            if Inhumidity3day[len(Inhumidity3day)-3] - Inhumidity3day[len(Inhumidity3day)-2] > 5 :
                Inhumidity3day[len(Inhumidity3day)-2] = int((Inhumidity3day[len(Inhumidity3day)-1] + Inhumidity3day[len(Inhumidity3day)-3])/2)
                print('low humidity')                                
                lines = 0 #DHT11 sometimes gives a low reading
                Inhum_csv = [] #list of current folder csv
                with open(current_folder[0]+'/data.csv') as f :
                    reader = csv.reader(f)
                    for row in f :
                        Inhum_csv.append(row)
                        lines +=1
                if lines > 2 : #must be at least 2
                    error_line =Inhum_csv[lines-2].split(',')
                    error_line[3] = str(Inhumidity3day[len(Inhumidity3day)-2]) #fix the low reading 3 is inside humid
                    s = ','
                    e3 = s.join(error_line) #unsplit the data 
                    Inhum_csv[lines-2] = e3
                    string_csv =''
                    for row in Inhum_csv :
                        string_csv += str(row) #form string from list
                    with open(current_folder[0]+'/data.csv','w') as fdw :
                            fdw.write(string_csv) #fix the current file csv    
    Hmax3 = max(Inhumidity3day)
    Hmin3 = min(Inhumidity3day) #the min and max of the full 3 days
    Intemperature3day.append(temp) # add this value
    if len(Intemperature3day) == 2160 : #have we got a full list
       del Intemperature3day[0] #delete the first if full
    if len(Intemperature3day) > 2 : #have we got more than 3
        if Intemperature3day[len(Intemperature3day)-1] - Intemperature3day[len(Intemperature3day)-2] > 2 :
            if Intemperature3day[len(Intemperature3day)-3] - Intemperature3day[len(Intemperature3day)-2] > 2 :
                Intemperature3day[len(Intemperature3day)-2] = int((Intemperature3day[len(Intemperature3day)-1] + Intemperature3day[len(Intemperature3day)-3])/2)
                print('low temperature')
                lines = 0 #DHT11 sometimes gives a low reading
                Inhum_csv = [] #list of current folder csv
                with open(current_folder[0]+'/data.csv') as f :
                    reader = csv.reader(f)
                    for row in f :
                        Inhum_csv.append(row)
                        lines +=1
                if lines > 2 : #must be at least 2
                    error_line =Inhum_csv[lines-2].split(',')
                    error_line[4] = str(Intemperature3day[len(Intemperature3day)-2]) #fix the low reading 4 is inside temp
                    s = ','
                    e3 = s.join(error_line) #unsplit the data 
                    Inhum_csv[lines-2] = e3
                    string_csv =''
                    for row in Inhum_csv :
                        string_csv += str(row) #form string from list
                    with open(current_folder[0]+'/data.csv','w') as fdw :
                            fdw.write(string_csv) #fix the current file csv
    Tmax3 = max(Intemperature3day)
    Tmin3 = min(Intemperature3day) #the min and max of the full 3 days

    if len(Inhumidity3day) == 1:
        sworking.append(humid) #very first one
    if len(Inhumidity3day) > 1: #must be more than 1 to put in average
        for n in range(0,len(Inhumidity3day)-1) : #move through and put in steps
            sworking.append(Inhumidity3day[n]) #always copy the first
            if(Inhumidity3day[n] != Inhumidity3day[n+1]) : #put in steps
                sworking.pop() #dont need if adding steps
                g = (Inhumidity3day[n]-Inhumidity3day[n+1])/4  #step size
                sworking.append(Inhumidity3day[n+1]+3*g) #first step
                sworking.append(Inhumidity3day[n+1]+2*g) #2nd step
                sworking.append(Inhumidity3day[n+1]+g) #3rd step
                sworking.append(Inhumidity3day[n+1]) #always copy the second
    displaywidth = round((len(Inhumidity3day)/2160)*len(humidity_conc))
    while len(sworking) > displaywidth : #remove at random
        del sworking[randint(0,len(sworking))-1] #until fits display
    Hmax = max(sworking)
    Hmin = min(sworking)
    if Hmax > Hmin : #d = distance from min bar to max bar
        x = (sh/4-37)/(Hmin-Hmax)
        d = - Hmax*x
    else : #no difference
        x= 0
        d = (sh/4-37)/2 #halfway up
    for n in range(0,len(sworking)) :
        humidity_conc[gridnumber-n-1] = sworking[len(sworking)-n-1]*x+d+46 #46 to bring to 0
    del sworking[:]  #delete this working version
    
    if len(Intemperature3day) == 1:
        sworking.append(temp) #very first one
    if len(Intemperature3day) > 1: #must be more than 1 to put in average
        for n in range(0,len(Intemperature3day)-1) : #move through and put in steps
            sworking.append(Intemperature3day[n]) #always copy the first
            if(Intemperature3day[n] != Intemperature3day[n+1]) : #put in steps
                sworking.pop() #dont need if adding steps
                g = (Intemperature3day[n]-Intemperature3day[n+1])/4  #step size
                sworking.append(Intemperature3day[n+1]+3*g) #first step
                sworking.append(Intemperature3day[n+1]+2*g) #2nd step
                sworking.append(Intemperature3day[n+1]+g) #3rd step
                sworking.append(Intemperature3day[n+1]) #always copy the second
    while len(sworking) > displaywidth : #remove at random
        del sworking[randint(0,len(sworking))-1] #until fits display
    Tmax = max(sworking)
    Tmin = min(sworking)
    if Tmax > Tmin :
        x = (sh/4-37)/(Tmin-Tmax)
        d = - Tmax*x
    else : #no difference
        x= 0
        d = (sh/4-37)/2 #halfway up
    for n in range(0,len(sworking)) : #46 to bring to 0
        temperature_conc[gridnumber-n-1] = sworking[len(sworking)-n-1]*x+d+46 
    del sworking[:]  #delete this working version
    
    cc.itemconfigure(humidityMax,text = str(Hmax3))
    cc.itemconfigure(humidity,text = str(humid))
    cc.itemconfigure(humidityMin,text = str(Hmin3))
    cc.itemconfigure(temperatureMax,text = str(Tmax3))
    cc.itemconfigure(temperature,text = str(temp))
    cc.itemconfigure(temperatureMin,text = str(Tmin3))
    ##  move_display()
    #display the current values by moving each display box from old spot.
    for n in range(0,gridnumber) : #subtract previous position
        cc.move(indoorH[n],0,humidity_conc[n]-indoor_hum_pos[n]) #move bars  
        indoor_hum_pos[n]=humidity_conc[n] #store new positions
        cc.move(indoorT[n],0,temperature_conc[n]-indoor_tem_pos[n]) #move bars  
        indoor_tem_pos[n]=temperature_conc[n] #store new positions
    cc.update()

#called by arduino_log on each data sample received
outhumidity3day =[] #three days of outdoor humidity samples
outtemperature3day =[] #three days of outdoor temperature samples  
out_humidity_conc = [] #gridnumber of humidity concentrated from 2160
out_temperature_conc = [] #gridnumber of temperature concentrated from 2160
sworking = [] #working list from data to display
def outdoor_log(humid,temp) :
    (cc,gridnumber,humidityMax,humidity,humidityMin,temperatureMax,temperature
     ,temperatureMin,sw,sh) = outdoor_displays
    outhumidity3day.append(humid) # add this value
    if len(outhumidity3day) == 2160 : #have we got a full list
       del outhumidity3day[0] #delete the first if full
    if len(outhumidity3day) > 2 : #have we got more than 3
        if outhumidity3day[len(outhumidity3day)-1] - outhumidity3day[len(outhumidity3day)-2] > 5 :
            if outhumidity3day[len(outhumidity3day)-3] - outhumidity3day[len(outhumidity3day)-2] > 5 :
                outhumidity3day[len(outhumidity3day)-2] = int((outhumidity3day[len(outhumidity3day)-1] + outhumidity3day[len(outhumidity3day)-3])/2)
                print('low out humidity')                                
                lines = 0 #DHT11 sometimes gives a low reading
                Inhum_csv = [] #list of current folder csv
                with open(current_folder[0]+'/data.csv') as f :
                    reader = csv.reader(f)
                    for row in f :
                        Inhum_csv.append(row)
                        lines +=1
                if lines > 2 : #must be at least 2
                    error_line =Inhum_csv[lines-2].split(',')
                    error_line[5] = str(outhumidity3day[len(outhumidity3day)-2]) #fix the low reading 5 is outside humid
                    s = ','
                    e3 = s.join(error_line) #unsplit the data 
                    Inhum_csv[lines-2] = e3
                    string_csv =''
                    for row in Inhum_csv :
                        string_csv += str(row) #form string from list
                    with open(current_folder[0]+'/data.csv','w') as fdw :
                            fdw.write(string_csv) #fix the current file csv    
    Hmax3 = max(outhumidity3day)
    Hmin3 = min(outhumidity3day) #the min and max of the full 3 days
    outtemperature3day.append(temp) # add this value
    if len(outtemperature3day) == 2160 : #have we got a full list
       del outtemperature3day[0] #delete the first if full
    if len(Intemperature3day) == 2160 : #have we got a full list
       del Intemperature3day[0] #delete the first if full
    if len(outtemperature3day) > 2 : #have we got more than 3
        if outtemperature3day[len(outtemperature3day)-1] - outtemperature3day[len(outtemperature3day)-2] > 2 :
            if outtemperature3day[len(outtemperature3day)-3] - outtemperature3day[len(outtemperature3day)-2] > 2 :
                outtemperature3day[len(outtemperature3day)-2] = int((outtemperature3day[len(outtemperature3day)-1] + outtemperature3day[len(outtemperature3day)-3])/2)
                print('low out mtemperature')
                lines = 0 #DHT11 sometimes gives a low reading
                Inhum_csv = [] #list of current folder csv
                with open(current_folder[0]+'/data.csv') as f :
                    reader = csv.reader(f)
                    for row in f :
                        Inhum_csv.append(row)
                        lines +=1
                if lines > 2 : #must be at least 2
                    error_line =Inhum_csv[lines-2].split(',')
                    error_line[6] = str(outtemperature3day[len(outtemperature3day)-2]) #fix the low reading 6 is outside temp
                    s = ','
                    e3 = s.join(error_line) #unsplit the data 
                    Inhum_csv[lines-2] = e3
                    string_csv =''
                    for row in Inhum_csv :
                        string_csv += str(row) #form string from list
                    with open(current_folder[0]+'/data.csv','w') as fdw :
                            fdw.write(string_csv) #fix the current file csv
    Tmax3 = max(outtemperature3day)
    Tmin3 = min(outtemperature3day) #the min and max of the full 3 days
   
    if len(outhumidity3day) == 1:
        sworking.append(humid) #very first one
    if len(outhumidity3day) > 1: #must be more than 1 to put in average
        for n in range(0,len(outhumidity3day)-1) : #move through and put in steps
            sworking.append(outhumidity3day[n]) #always copy the first
            if(outhumidity3day[n] != outhumidity3day[n+1]) : #put in steps
                sworking.pop() #dont need if adding steps
                g = (outhumidity3day[n]-outhumidity3day[n+1])/4  #step size
                sworking.append(outhumidity3day[n+1]+3*g) #first step
                sworking.append(outhumidity3day[n+1]+2*g) #2nd step
                sworking.append(outhumidity3day[n+1]+g) #3rd step
                sworking.append(outhumidity3day[n+1]) #always copy the second
    displaywidth = round((len(outhumidity3day)/2160)*len(out_humidity_conc))
    while len(sworking) > displaywidth : #remove at random
        del sworking[randint(0,len(sworking))-1] #until fits display
    Hmax = max(sworking)
    Hmin = min(sworking)
    if Hmax > Hmin : #d = distance from min bar to max bar
        x = (sh/4-39)/(Hmin-Hmax) #this is bit smaller
        d = - Hmax*x
    else : #no difference
        x= 0
        d = (sh/4-39)/2 #halfway up
    for n in range(0,len(sworking)) :  #40 to bring to 0 in this smaller box
        out_humidity_conc[gridnumber-n-1] = sworking[len(sworking)-n-1]*x+d+40+sh/4 
    del sworking[:]  #delete this working version

    if len(outtemperature3day) == 1:
        sworking.append(temp) #very first one
    if len(outtemperature3day) > 1: #must be more than 1 to put in average
        for n in range(0,len(outtemperature3day)-1) : #move through and put in steps
            sworking.append(outtemperature3day[n]) #always copy the first
            if(outtemperature3day[n] != outtemperature3day[n+1]) : #put in steps
                sworking.pop() #dont need if adding steps
                g = (outtemperature3day[n]-outtemperature3day[n+1])/4  #step size
                sworking.append(outtemperature3day[n+1]+3*g) #first step
                sworking.append(outtemperature3day[n+1]+2*g) #2nd step
                sworking.append(outtemperature3day[n+1]+g) #3rd step
                sworking.append(outtemperature3day[n+1]) #always copy the second
    while len(sworking) > displaywidth : #remove at random
        del sworking[randint(0,len(sworking))-1] #until fits display
    Tmax = max(sworking)
    Tmin = min(sworking)
    if Tmax > Tmin :
        x = (sh/4-39)/(Tmin-Tmax)
        d = - Tmax*x
    else : #no difference
        x= 0
        d = (sh/4-39)/2 #halfway up
    for n in range(0,len(sworking)) : #46 to bring to 0
        out_temperature_conc[gridnumber-n-1] = sworking[len(sworking)-n-1]*x+d+40+sh/4 
    del sworking[:]  #delete this working version

    cc.itemconfigure(humidityMax,text = str(Hmax3))
    cc.itemconfigure(humidity,text = str(humid))
    cc.itemconfigure(humidityMin,text = str(Hmin3))
    cc.itemconfigure(temperatureMax,text = str(Tmax3))
    cc.itemconfigure(temperature,text = str(temp))
    cc.itemconfigure(temperatureMin,text = str(Tmin3))
    ##  move_display()
    #display the current values by moving each display box from old spot.
    for n in range(0,gridnumber) : #subtract previous position
        cc.move(outdoorH[n],0,out_humidity_conc[n]-outdoor_hum_pos[n]) #move bars  
        outdoor_hum_pos[n]=out_humidity_conc[n] #store new positions
        cc.move(outdoorT[n],0,out_temperature_conc[n]-outdoor_tem_pos[n]) #move bars  
        outdoor_tem_pos[n]=out_temperature_conc[n] #store new positions
    cc.update()
    
#called by arduino_log on each data sample received
pressure3day =[] #three days of pressure samples
lightning3day =[] #three days of lightning samples  
pressure_conc = [] #gridnumber of pressure concentrated from 2160
lightning_conc = [] #gridnumber of lightning concentrated from 2160
lightning_total = [] #the total number in a period
lightning_start_time = []
pworking = [] #working list from data to display
def pressure_lightning_log(pnorm,flashes) :
    (cc,gridnumber,pressure_min,pressure_max,Nflashes
     ,sw,sh) = pressure_lightning_displays
    pressure3day.append(pnorm) # add this value
    if len(pressure3day) == 2160 : #have we got a full list
       del pressure3day[0] #delete the first if full
    if len(pressure3day) > 2 : #have we got more than 3
        if pressure3day[len(pressure3day)-2] - pressure3day[len(pressure3day)-1] > 20 :
            if pressure3day[len(pressure3day)-2] - pressure3day[len(pressure3day)-3] > 20 :
                pressure3day[len(pressure3day)-2] = int((pressure3day[len(pressure3day)-1] + pressure3day[len(pressure3day)-3])/2)
                print('high pressure')
                lines = 0 #bmp180 sometimes gives a high reading
                Inhum_csv = [] #list of current folder csv
                with open(current_folder[0]+'/data.csv') as f :
                    reader = csv.reader(f)
                    for row in f :
                        Inhum_csv.append(row)
                        lines +=1
                if lines > 2 : #must be at least 2
                    error_line =Inhum_csv[lines-2].split(',')
                    error_line[7] = str(pressure3day[len(pressure3day)-2]) #fix the low reading 7 is pressure
                    s = ','
                    e3 = s.join(error_line) #unsplit the data 
                    Inhum_csv[lines-2] = e3
                    string_csv =''
                    for row in Inhum_csv :
                        string_csv += str(row) #form string from list
                    with open(current_folder[0]+'/data.csv','w') as fdw :
                            fdw.write(string_csv) #fix the current file csv
    Pmax3 = max(pressure3day)
    Pmin3 = min(pressure3day) #the min and max of the full 3 days
    cc.itemconfigure(pressure_min,text = str(math.floor(Pmin3/10)))
    cc.itemconfigure(pressure_max,text = str(math.floor(Pmax3/10)))
    if len(pressure3day) == 1:
        pworking.append(pnorm) #very first one
    if len(pressure3day) > 1: #must be more than 1 to put in average
        for n in range(0,len(pressure3day)-1) : #move through and put in steps
            pworking.append(pressure3day[n]) #always copy the first
            if(math.floor(pressure3day[n]/10) != math.floor(pressure3day[n+1]/10)) : #put in steps
                pworking.pop() #dont need if adding steps
                g = (pressure3day[n]-pressure3day[n+1])/4  #step size
                pworking.append(pressure3day[n+1]+3*g) #first step
                pworking.append(pressure3day[n+1]+2*g) #2nd step
                pworking.append(pressure3day[n+1]+g) #3rd step
                pworking.append(pressure3day[n+1]) #always copy the second
    displaywidth = round((len(pressure3day)/2160)*len(pressure_conc))
    while len(pworking) > displaywidth : #remove at random
        del pworking[randint(0,len(pworking))-1] #until fits display
    Tmax = max(pworking)
    Tmin = min(pworking)
    if Tmax > Tmin :
        x = (sh/4-37)/(Tmin-Tmax)
        d = - Tmax*x
    else : #no difference
        x= 0
        d = (sh/4-37)/2 #halfway up
    for n in range(0,len(pworking)) : #add 1037 to bring to 0
        pressure_conc[gridnumber-n-1] = pworking[len(pworking)-n-1]*x+d+1037
    del pworking[:]  #delete this working version
    
    lightning3day.append(lightning_total[0]) # add this value
    if len(lightning3day) == 2160 : #have we got a full list
       del lightning3day[0] #delete the first if full
    Lmax3 = max(lightning3day)
    Lmin3 = min(lightning3day)
    cc.itemconfigure(Nflashes,text = str(Lmax3))
    if len(lightning3day) == 1:
        pworking.append(flashes) #very first one
    if len(lightning3day) > 1: #must be more than 1 to put in average
        for n in range(0,len(lightning3day)-1) : #move through and put in steps
            pworking.append(lightning3day[n]) #always copy the first
            if(math.floor(lightning3day[n]/10) != math.floor(lightning3day[n+1]/10)) : #put in steps
                pworking.pop() #dont need if adding steps
                g = (lightning3day[n]-lightning3day[n+1])/4  #step size
                pworking.append(lightning3day[n+1]+3*g) #first step
                pworking.append(lightning3day[n+1]+2*g) #2nd step
                pworking.append(lightning3day[n+1]+g) #3rd step
                pworking.append(lightning3day[n+1]) #always copy the second
    Ldisplaywidth = round((len(lightning3day)/2160)*len(lightning_conc))
    while len(pworking) > Ldisplaywidth : #remove at random
        del pworking[randint(0,len(pworking))-1] #until fits display
    Lmax = max(pworking)
    Lmin = min(pworking)
    if Lmax > Lmin :
        x = (sh/4-37)/(Lmin-Lmax)
        d = - Lmax*x
    else : #no difference
        x= 0
        d = (sh/4-37)/2 #halfway up
    for n in range(0,len(pworking)) : #add 1037 to bring to 0
        lightning_conc[gridnumber-n-1] = pworking[len(pworking)-n-1]*x+d+1037
    del pworking[:]  #delete this working version
    ##  move_display()
    #display the current values by moving each display box from old spot.
    for n in range(0,gridnumber) : #subtract previous position
        cc.move(pressure[n],0,pressure_conc[n]-pressure_pos[n]) #move bars  
        pressure_pos[n]=pressure_conc[n] #store new positions
        cc.move(lightning[n],0,lightning_conc[n]-lightning_pos[n]) #move bars  
        lightning_pos[n]=lightning_conc[n] #store new positions
    cc.update()

#called by arduino_log on each data sample received
windspeed3day =[] #three days of windspeed samples
rainfall3day =[] #three days of rainfall samples  
windspeed_conc = [] #gridnumber of windspeed concentrated from 2160
rainfall_conc = [] #gridnumber of rainfall concentrated from 2160
rainfall_total = [] #the total number in a period
rainfall_start_time = []
wworking = [] #working list from data to display
def windspeed_rainfall_log(wind_Speed,rainfall):
    (cc,gridnumber,windspeed_ave,windspeed_max,Nrainfall
     ,sw,sh) = windspeed_rainfall_displays
    windspeed3day.append(wind_Speed) # add this value
    if len(windspeed3day) == 2160 : #have we got a full list
       del windspeed3day[0] #delete the first if full 
    Wmax = max(windspeed3day)
    Amax = round((float)(sum(windspeed3day))/len(windspeed3day),1)
    cc.itemconfigure(windspeed_ave,text = str(Amax))
    cc.itemconfigure(windspeed_max,text = str(Wmax))

    rainfall3day.append(rainfall_total[0]) # add this value
    if len(rainfall3day) == 2160 : #have we got a full list
       del rainfall3day[0] #delete the first if full
    Rmax3 = max(rainfall3day)
    cc.itemconfigure(Nrainfall,text = str(Rmax3))
    if len(rainfall3day) == 1:
        wworking.append(rainfall) #very first one
    if len(rainfall3day) > 1: #must be more than 1 to put in average
        for n in range(0,len(rainfall3day)-1) : #move through and put in steps
            wworking.append(rainfall3day[n]) #always copy the first
            if(math.floor(rainfall3day[n]/10) != math.floor(rainfall3day[n+1]/10)) : #put in steps
                wworking.pop() #dont need if adding steps
                g = (rainfall3day[n]-rainfall3day[n+1])/4  #step size
                wworking.append(rainfall3day[n+1]+3*g) #first step
                wworking.append(rainfall3day[n+1]+2*g) #2nd step
                wworking.append(rainfall3day[n+1]+g) #3rd step
                wworking.append(rainfall3day[n+1]) #always copy the second
    displaywidth = round((len(rainfall3day)/2160)*len(rainfall_conc))
    while len(wworking) > displaywidth : #remove at random
        del wworking[randint(0,len(wworking))-1] #until fits display
    Tmax = max(wworking)
    Tmin = min(wworking)
    if Tmax > Tmin :
        x = (sh/4-52)/(Tmin-Tmax)
        d = - Tmax*x
    else : #no difference
        x= 0
        d = (sh/4-52)/2 #halfway up
    for n in range(0,len(wworking)) : #add 1037 to bring to 0
        rainfall_conc[gridnumber-n-1] = wworking[len(wworking)-n-1]*x+d-sh/4+66+1000-14
    del wworking[:]  #delete this working version

    if len(windspeed3day) == 1:
        wworking.append(wind_Speed) #very first one
    if len(windspeed3day) > 1: #must be more than 1 to put in average
        for n in range(0,len(windspeed3day)-1) : #move through and put in steps
            wworking.append(windspeed3day[n]) #always copy the first
            if(math.floor(windspeed3day[n]/10) != math.floor(windspeed3day[n+1]/10)) : #put in steps
                wworking.pop() #dont need if adding steps
                g = (windspeed3day[n]-windspeed3day[n+1])/4  #step size
                wworking.append(windspeed3day[n+1]+3*g) #first step
                wworking.append(windspeed3day[n+1]+2*g) #2nd step
                wworking.append(windspeed3day[n+1]+g) #3rd step
                wworking.append(windspeed3day[n+1]) #always copy the second
    displaywidth = round((len(windspeed3day)/2160)*len(windspeed_conc))
    while len(wworking) > displaywidth : #remove at random
        del wworking[randint(0,len(wworking))-1] #until fits display
    Tmax = max(wworking)
    Tmin = min(wworking)
    if Tmax > Tmin :
        x = (sh/4-52)/(Tmin-Tmax)
        d = - Tmax*x
    else : #no difference
        x= 0
        d = (sh/4-52)/2 #halfway up
    for n in range(0,len(wworking)) : #add 1037 to bring to 0
        windspeed_conc[gridnumber-n-1] = wworking[len(wworking)-n-1]*x+d-sh/4+66+1000-14
    del wworking[:]  #delete this working version

    ##  move_display()
    #display the current values by moving each display box from old spot.
    for n in range(0,gridnumber) : #subtract previous position
        cc.move(windspeed[n],0,windspeed_conc[n]-windspeed_pos[n]) #move bars  
        windspeed_pos[n]=windspeed_conc[n] #store new positions
        cc.move(rainfalld[n],0,rainfall_conc[n]-rainfall_pos[n]) #move bars  
        rainfall_pos[n]=rainfall_conc[n] #store new positions
    cc.update()
    
#called on interupt sent from arduino by logging recieved
#//Pi zero only receives least 7 bits in i2c read from arduino
#//Pi A and B series receives full 8 bits.
#//if byte is > 127 use two bytes as in IR commands
#//0,1 for MSB IR. 2,3 for LSB IR. 4,5 for humid and temp
#6,7 for outside humid temp, 8 for lightning, 9 for wind speed
#10 for rainfall
def Arduino_log(channel):
    show_clock() #show the clock each time receive new data
    writeNumber(4)  #in.humidity
    humid = readNumber()    
    writeNumber(5)  #in.temperature
    temp = readNumber()
    writeNumber(10)  #0ut.humidity
    out_humid = readNumber()
    writeNumber(9)  #0ut.temperature
    out_temp = readNumber()
    writeNumber(6)  #out lightning
    Lightning = readNumber()
##  keep sum of flashes going until 1 hour with none
    if Lightning > 0 :
        lightning_start_time[0] = int(time.time())
    elif int(time.time()) - lightning_start_time[0] > 3590 :
        lightning_total[0] = 0
    lightning_total[0] += Lightning # add if 0 or higher
    Lightning = lightning_total[0] # keep running total
    writeNumber(8)  #0ut wind_speed
    Wind_Speed = readNumber()
    writeNumber(7)  #0ut.rainfall
    rainfall = readNumber()
##  keep sum of rainfall going until 1 hour with none
    if rainfall > 0 :
        rainfall_start_time[0] = int(time.time())
    elif int(time.time()) - rainfall_start_time[0] > 3590 :
        rainfall_total[0] = 0
    rainfall_total[0] += rainfall # add if 0 or higher
    rainfall = rainfall_total[0] # keep running total
##    print(rainfall,Lightning)
    pnorm = sample_pressure()   # get air pressure from BMP180
    dt = ds3231.read_all()
    cf = str(month[dt[1]-1])+' 20'+str(dt[0])
    if current_folder[0] != cf:  #are we onto next month      
        os.makedirs(cf) #setup current data folder
        current_folder[0] = cf #update the current month folder
        with open(cf+'/data.csv','w') as f :
            writer = csv.writer(f) #setup current data file header
            writer.writerow(['Date','Hour','Minute','In_Humidity'
                             ,'In_temperature','Out_Humidity'
                             ,'Out_Temperature','Pressure','Lightning'
                             ,'Wind_Speed','Rainfall'])
    with open(current_folder[0]+'/data.csv','a') as f :
        writer = csv.writer(f) #store data in current folder
        writer.writerow([dt[2],dt[4],dt[5],humid,temp,out_humid,out_temp
                         ,pnorm,Lightning,Wind_Speed,rainfall]) #store data
    indoor_log(humid,temp) #display indoor data
    outdoor_log(out_humid,out_temp)  #display indoor data
    pressure_lightning_log(pnorm,Lightning) #display pressure and lightning flashes
    windspeed_rainfall_log(Wind_Speed,rainfall) #display windspeed and rainfall
    
#called from run program when program is started
current_folder = [] #the current working data folder
month_data = [] #store for one months data
sample_times = [] #store for 2159 times of samples from time now
days_month = [31,28,31,30,31,30,31,31,30,31,30,31] #number days in month
##if power off during changeover year
##does not display missing january data
def first_run() :
    dt = ds3231.read_all()
    #Return tuple of year, month, date, day, hours, minutes, seconds.
    date = dt[2]
    hour = dt[4]
    minute = dt[5]
    for n in range(0,2159) :
        minute -= 2
        if minute <= 0 : # less than 0 minutes
            minute = 59
            hour -= 1 # previous hour
            if hour == -1 : # less than 0 hours
                hour = 23
                date -= 1 #previous day
                if date == 0 : #less than 1 date(1 to 30?)
                   if dt[1] != 1 : # is january
                       date = days_month[dt[1]-2] # no just previous month
                   else :
                       date = days_month[11] #previous month december            
        sample_times.insert(0,[date,hour,minute]) # start now and work back to 2159 
    #2159 samples are required to give full 3 day record
    l_s = sample_times[0]  #the latest sample time
    number_this_month = 0 #save this number
    for n in range(2159-1,0,-1) :
        time = sample_times[n]
        if l_s[0] < time[0] : #is the day in previous month
            number_this_month = n #save this number
            break
    f_s = sample_times[2158]  #the earlist sample time
    latest_sample_time = int(l_s[0])*60*24 + int(l_s[1])*60 + int(l_s[2])
    #use to load only those samples in 3day range
    cf = str(month[dt[1]-1])+' 20'+str(dt[0])
    if dt[1] != 1 : # is january not same year for previous month
        cp = str(month[dt[1]-2])+' 20'+str(dt[0])
    else : # change to previous year
        cp = str(month[11])+' 20'+str(dt[0]-1)
    current_folder.append(cf) #setup current folder path  
    if not os.path.isdir(cf):
        os.makedirs(cf) #setup current data folder
        with open(cf+'/data.csv','w') as f :
            writer = csv.writer(f) #setup current data file header
            writer.writerow(['Date','Hour','Minute','In_Humidity'
                             ,'In_temperature','Out_Humidity'
                             ,'Out_Temperature','Pressure','Lightning'
                             ,'Wind_Speed','Rainfall'])
    if os.path.isdir(cp) and number_this_month < 2158: #and if need values
        with open(cp+'/data.csv') as f : #add previous month if exists
            reader = csv.reader(f) #if previous folder exist
            header_row = next(reader) #strip header
            try:
                for row in reader :
                    temp = row
                    tnow = int(row[0])*60*24 + int(row[1])*60 + int(row[2])
                    #only use those in 3 day range
                    if tnow > latest_sample_time :
                        month_data.append(temp)
            except:#corupt data due to power loss during write
               #read/write entire file to remove corruption
                print('except previous')
                with open(cp+'/data.csv') as fd :
                    alldata = fd.read()
                while alldata[-1] != '\n' :
                    alldata = alldata[:-1]
                with open(cp+'/data.csv','w') as fdw :
                    fdw.write(alldata)
    with open(cf+'/data.csv') as f : #add this month
        if f_s[0] < l_s[0] :
            latest_sample_time = 1  #starting on new month
        reader = csv.reader(f)
        header_row = next(reader) #strip header
        try:
            for row in reader :
                temp = row
                tnow = int(row[0])*60*24 + int(row[1])*60 + int(row[2])
                #only use those in 3 day range
                if tnow > latest_sample_time :
                    month_data.append(temp)
        except:#corupt data due to power loss during write
           #read/write entire file to remove corruption
            print('except')
            with open(cf+'/data.csv') as fd :
                alldata = fd.read()
            while alldata[-1] != '\n' :
                alldata = alldata[:-1]
            with open(cf+'/data.csv','w') as fdw :
                fdw.write(alldata)
    savedN = 1
    for n in range(2159-1,0,-1) :
        time = sample_times[n]
        timenow = time[0]*24*60 + time[1]*60 + time[2]
        if len(month_data)-savedN == -1 :
            break # used up all saved values
        saved = month_data[len(month_data)-savedN]
        savedlast =int(saved[0])*24*60 + int(saved[1])*60 + int(saved[2])
        Inhumidity3day.insert(0,int(saved[3])) # add this value
        Intemperature3day.insert(0,int(saved[4])) # add this value
        outhumidity3day.insert(0,int(saved[5])) # add this value
        outtemperature3day.insert(0,int(saved[6])) # add this value
        pressure3day.insert(0,int(saved[7])) # add this value
        lightning3day.insert(0,int(saved[8])) # add this value
        windspeed3day.insert(0,int(saved[9])) # add this value
        rainfall3day.insert(0,int(saved[10])) # add this value
        if timenow-savedlast < 2 :
            savedN +=1 # used up one saved value
        
#initialise BCM pin 17 to call interup routine Arduino_log
#called from start code will never run at same time as IR irq
def setup_log_interupts():
    #irq pulled high when arduino has log sample 2 minutes  
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(17, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)   
    GPIO.add_event_detect(17, GPIO.RISING, callback=Arduino_log)

#set up the display current data screen call from menu code
#set up the display current indoor temperature
indoor_displays = []  #refere to each displays items
#(cc,gridnumber,humidityMax,humidity,humidityMin,temperatureMax,temperature
     #,temperatureMin,timeaxis,sw,sh)
indoorH = []  # the indoor humid graph elements
indoorT = []  # the indoor temp graph elements
indoor_hum_pos = []  #current humid position
indoor_tem_pos = []  #current temperature position
def display_current_indoor(cc,sw,sh):
    indoor_displays.append(cc)
    gridnumber = sw-120-10 #total number of display rectangles available
    for n in range(0,gridnumber) :
        humidity_conc.append(0) #this time start the concetrated as 0
        temperature_conc.append(0) #this time start the concetrated as 0
    indoor_displays.append(gridnumber) #this is the number of rectangles
    #the indoor TH display box
    cc.create_rectangle((60,4),(sw-60,sh/4-16),outline='white',width=8,
                        fill='black')
    cc.create_line((sw/3+20,4),(sw/3+20,sh/4-16),width=8,fill='white')
    cc.create_line((2*sw/3-20,4),(2*sw/3-20,sh/4-16),width=8,fill='white')
    #the outdoor TH display box
    cc.create_rectangle((60,sh/4),(sw-60,sh/2-24),outline='white',width=8,
                        fill='black')
    cc.create_line((sw/3+20,sh/4),(sw/3+20,sh/2-24),width=8,fill='white')
    cc.create_line((2*sw/3-20,sh/4),(2*sw/3-20,sh/2-24),
                   width=8,fill='white')
    cc.create_line((sw-60,sh/2-24+8),(sw-60,sh/2-24+52),width=8,fill='blue')
    #the pressure/lightning display box
    cc.create_rectangle((60,sh/2+36),(sw-60,sh/2+sh/4+16),outline='white',
                        width=8,fill='black')
    cc.create_line((sw/3+20,sh/2+36),(sw/3+20,sh/2+sh/4+16,),
                   width=8,fill='white')
    cc.create_line((2*sw/3-20,sh/2+36),(2*sw/3-20,sh/2+sh/4+16),
                   width=8,fill='white')
    #the wind/rainfall display box
    cc.create_rectangle((60,sh/2+sh/4+32),(sw-60,sh-4),outline='white',
                        width=8,fill='black')
    cc.create_line((sw/3+20,sh/2+sh/4+32),(sw/3+20,sh-4),
                   width=8,fill='white')
    cc.create_line((2*sw/3-20,sh/2+sh/4+32),(2*sw/3-20,sh-4),
                   width=8,fill='white')
    for n in range(0,gridnumber): #each is 2 wide and spaced 1 apart
        oval = cc.create_rectangle((n+64,-38),(n+66,-30),outline = 'green',
                                   fill = 'green')
        indoorH.append(oval) #humid display bars
        indoor_hum_pos.append(0)  #start at zero
        oval = cc.create_rectangle((n+64,-38),(n+66,-30),outline = '#FF7F00',
                                   fill = '#FF7F00')
        indoorT.append(oval) #temp display bars
        indoor_tem_pos.append(0)  #start at zero
    humidityMax =cc.create_text((28, 20),fill='green',text='mx',
                                font=('Helvetica', '36'))
    indoor_displays.append(humidityMax)
    humidity =cc.create_text((28, (sh/4-37)/2+8),fill='green',text='hm',
                             font=('Helvetica', '36'))
    indoor_displays.append(humidity)
    humidityMin =cc.create_text((28, sh/4-37),fill='green',text='mn',
                                font=('Helvetica', '36'))
    indoor_displays.append(humidityMin)
    temperatureMax =cc.create_text((sw-28, 20),fill='#FF7F00',text='mx',
                                   font=('Helvetica', '36'))
    indoor_displays.append(temperatureMax)
    temperature =cc.create_text(sw-28, (sh/4-37)/2+8,fill='#FF7F00',text='tm',
                                font=('Helvetica', '36'))
    indoor_displays.append(temperature)
    temperatureMin =cc.create_text((sw-28, sh/4-37),fill='#FF7F00',text='mn',
                                   font=('Helvetica', '36'))
    indoor_displays.append(temperatureMin)
    timeaxis = cc.create_text((sw/2, sh/2+6),fill='blue',text='UPDATE SOON',
                              font=('Helvetica', '36'))
    indoor_displays.append(timeaxis)
    indoor_displays.append(sw)
    indoor_displays.append(sh) #add the screen dimensions

#set up the display current outdoor temperature
outdoor_displays = []  #refere to each displays items
#(cc,gridnumber,humidityMax,humidity,humidityMin,temperatureMax,temperature
     #,temperatureMin,sw,sh)
outdoorH = []  # the outdoor humid graph elements
outdoorT = []  # the outdoor temp graph elements
outdoor_hum_pos = []  #current humid position
outdoor_tem_pos = []  #current temperature position
def display_current_outdoor(cc,sw,sh):
    outdoor_displays.append(cc)
    gridnumber = sw-120-10 #total number of display rectangles available
    for n in range(0,gridnumber) :
        out_humidity_conc.append(0) #this time start the concetrated as 0
        out_temperature_conc.append(0) #this time start the concetrated as 0
    outdoor_displays.append(gridnumber) #this is the number of rectangles
    for n in range(0,gridnumber): #each is 2 wide and spaced 1 apart
        oval = cc.create_rectangle((n+64,-38),(n+66,-30),outline = 'blue',
                                   fill = 'blue')
        outdoorH.append(oval) #humid display bars
        outdoor_hum_pos.append(0)  #start at zero
        oval = cc.create_rectangle((n+64,-38),(n+66,-30),outline = '#FF007F',
                                   fill = '#FF007F')
        outdoorT.append(oval) #temp display bars
        outdoor_tem_pos.append(0)  #start at zero
    humidityMax =cc.create_text((28, sh/4 + 16),fill='blue',text='ox',
                                font=('Helvetica', '36'))
    outdoor_displays.append(humidityMax)
    humidity =cc.create_text((28, sh/4+sh/8-16 ),fill='blue',text='oh',
                             font=('Helvetica', '36'))
    outdoor_displays.append(humidity)
    humidityMin =cc.create_text((28, sh/2-45),fill='blue',text='on',
                                font=('Helvetica', '36'))
    outdoor_displays.append(humidityMin)
    temperatureMax =cc.create_text((sw-28,sh/4+16),fill='#FF007F',text='ox',
                                   font=('Helvetica', '36'))
    outdoor_displays.append(temperatureMax)
    temperature =cc.create_text((sw-28,sh/4+sh/8-16),fill='#FF007F',text='ot',
                                font=('Helvetica', '36'))
    outdoor_displays.append(temperature)
    temperatureMin =cc.create_text((sw-28,sh/2-45),fill='#FF007F',text='on',
                                   font=('Helvetica', '36'))
    outdoor_displays.append(temperatureMin)
    outdoor_displays.append(sw)
    outdoor_displays.append(sh) #add the screen dimensions
 
#set up the display current pressure/lightning
pressure_lightning_displays = []  #refere to each displays items
#(cc,gridnumber,pressureMin,pressureMax,lightning,sw,sh)
pressure = []  # the pressure graph elements
lightning = []  # the lightning graph elements
pressure_pos = []  #current pressure position
lightning_pos = []  #current lightning position
def display_pressure_lightning(cc,sw,sh):
    pressure_lightning_displays.append(cc)
    gridnumber = sw-120-10 #total number of display rectangles available
    pressure_lightning_displays.append(gridnumber)
    for n in range(0,gridnumber) :
        pressure_conc.append(0) #this time start current bar position = 0
        lightning_conc.append(0) #this time start current bar position = 0
        pressure_pos.append(0) #this time start the old bar position = 0
        lightning_pos.append(0) #this time start the old bar position = 0
    min_press = cc.create_text((4, sh/2-16+sh/4+34),fill='red',text='pmin',
                   font=('Helvetica', '26'),anchor ='nw' ,angle=90)
    pressure_lightning_displays.append(min_press)
    max_press = cc.create_text((4, (sh/2-16)+sh/8+34),fill='red',text='pmax',
                   font=('Helvetica', '26'),anchor ='nw' ,angle=90)
    pressure_lightning_displays.append(max_press)
    Nflashes = cc.create_text((sw-62,(sh/2-16)+sh/4+20),fill='yellow',text='flashes'
                             ,font=('Helvetica', '44'),anchor ='nw' ,angle=90)
    pressure_lightning_displays.append(Nflashes)
    for n in range(0,gridnumber): #each is 2 wide and spaced 1 apart
        oval = cc.create_rectangle((n+64,sh/2+3-1000),(n+66,sh/2+11-1000),
                                   outline = 'red',fill = 'red')
        pressure.append(oval) #pressure display elements
        oval = cc.create_rectangle((n+64,sh/2+3-1000),(n+66,sh/2+11-1000),
                                   outline = 'yellow',fill = 'yellow')
        lightning.append(oval) #lightning display elements
    pressure_lightning_displays.append(sw)
    pressure_lightning_displays.append(sh)
    lightning_total.append(0)
    lightning_start_time.append(int(time.time())) 

#set up the display current windspeed/rainfall
windspeed_rainfall_displays = []  #refere to each displays items
#(cc,gridnumber,windspeedMin,windspeedMax,rainfall,sw,sh)
windspeed = []  # the windspeed graph elements
rainfalld = []  # the rainfall graph elements
windspeed_pos = []  #current windspeed position
rainfall_pos = []  #current rainfall position
def display_windspeed_rainfall(cc,sw,sh):
    windspeed_rainfall_displays.append(cc)
    gridnumber = sw-120-10 #total number of display rectangles available
    windspeed_rainfall_displays.append(gridnumber)
    for n in range(0,gridnumber) :
        windspeed_conc.append(0) #this time start current bar position = 0
        rainfall_conc.append(0) #this time start current bar position = 0
        windspeed_pos.append(0) #this time start the old bar position = 0
        rainfall_pos.append(0) #this time start the old bar position = 0
    ave_wind = cc.create_text((4, sh-8),fill='red',text='aw',
                   font=('Helvetica', '32'),anchor ='nw' ,angle=90)
    windspeed_rainfall_displays.append(ave_wind)
    max_wind = cc.create_text((4, sh-sh/8-10),fill='red',text='wx',
                   font=('Helvetica', '32'),anchor ='nw' ,angle=90)
    windspeed_rainfall_displays.append(max_wind)
    Nrainfall = cc.create_text(sw-62,sh-16,fill='yellow',text='rainfall'
                             ,font=('Helvetica', '44'),anchor ='nw' ,angle=90)
    windspeed_rainfall_displays.append(Nrainfall)
    for n in range(0,gridnumber): #each is 2 wide and spaced 1 apart
        oval = cc.create_rectangle((n+64,sh+3-20-1000),(n+66,sh+11-20-1000),
                                   outline = 'red',fill = 'red')
        windspeed.append(oval) #windspeed display elements
        oval = cc.create_rectangle((n+64,sh+3-20-1000),(n+66,sh+11-20-1000),
                                   outline = 'yellow',fill = 'yellow')
        rainfalld.append(oval) #rainfall display elements
    windspeed_rainfall_displays.append(sw)
    windspeed_rainfall_displays.append(sh)
    rainfall_total.append(0)
    rainfall_start_time.append(int(time.time())) 
