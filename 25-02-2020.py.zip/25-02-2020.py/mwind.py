from tkinter import*
import time
import SDL_DS3231
from threading import Thread
import smbus
import os
import RPi.GPIO as GPIO
import logging as log

display_number = [0] #the current displayed frame = start menu

#The first time through need to setup the weather IR folder
foldername = 'WEATHERIR'
IRcommandsfile = 'WEATHERIR/IRcommands.txt'
displaynumberfile = 'WEATHERIR/displaynumber.txt'
IRcommands=[]  #the IR commands [OK,left,up,right,down]
def first_run():
    if not os.path.isdir(foldername):
       os.makedirs(foldername) #setup WEATHER folder
    try:
    #the IR commands have been set and stored so load them
        with open(IRcommandsfile, 'r') as fn:
            for line in fn:
                IRcommands.append(line.rstrip())            
    except FileNotFoundError:
        #IR commands dont exist so leave on start menu page
        pass
    try:
    #the IR disply_number has been saved. Return to last screen
        with open(displaynumberfile, 'r') as fn:
            display_number[0] = int(fn.read())
    except FileNotFoundError:
        pass #no need to do anything stay on start menu page

# This is the I2C address we setup in the Arduino Program
bus = smbus.SMBus(1)
address = 0x04  #I2C arduino address
def writeNumber(value):
 bus.write_byte(address, value) #send address 0 to 255
 return -1
def readNumber():
 number = bus.read_byte(address) #get data from I2C address
 return number

#called on interupt sent from arduino by IR command recieved
#//Pi zero only receives least 7 bits in i2c read from arduino
#//Pi A and B series receives full 8 bits.
#//if byte is > 127 use two bytes as in IR commands
#//0,1 for MSB IR. 2,3 for LSB IR. 4,5 for humid and temp
def Arduino_irq(channel):
    writeNumber(0)  #IR address MSB
    nh = readNumber() #msbit      
    writeNumber(1)  #IR add ls7bits
    nl = readNumber()
    Hnum = (nh*128 + nl)*256 # move to High 8 bits
    writeNumber(2)  #IR command MSB
    nh = readNumber() #msbit      
    writeNumber(3)  #IR com ls7bits
    nl = readNumber()
    Hnum = Hnum + nh*128 + nl # add the command 8 bits
    Hnums = '{:02X}'.format(Hnum) #nice HEX format
    
    if len(IRcommands) < 5 :
        setupIR(Hnums) #display the IR command inputs
    else :  #must be 5, all commands are set
        Ymove = round((screen_size[1] - 45)/8) + 5
        if display_number[0] == 2 : #we are on the clock set page
            change_clock(Hnums)  
        if display_number[0] == 0 : #we are on the menu page
            if Hnums == IRcommands[3]: #move right not to far
                if cursor_position[0] < 630 :
                    move_cursor(100,0)
                    cursor_position[0] += 100
            if Hnums == IRcommands[1]: #move left not to far
                if cursor_position[0] > 530 :
                    move_cursor(-100,0)
                    cursor_position[0] -=100
            if Hnums == IRcommands[2]: #move up not to far
                if cursor_position[1] > 60 :
                    move_cursor(0,-Ymove)
                    cursor_position[1] -= Ymove
            if Hnums == IRcommands[4]: #move down not to far
                if cursor_position[1] < screen_size[1]-Ymove :
                    move_cursor(0,Ymove)
                    cursor_position[1] += Ymove
            if Hnums == IRcommands[0]: #the OK select button
                set_display_screen()  #we are on the menu screen                
    fivetimes(Hnums) #check to see if five fast clicks


#called on every IR command recieved. Find 5 clicks in 3 seconds
timerx=[]
def fivetimes(Hnums):
        timerx.append(time.time()) #this may be a historical time
        five = len(timerx)
        if(five == 2): 
              if(timerx[1]-timerx[0] > 0.75):
                timerx.pop(),timerx.pop() #too slow drop the rubbish  
        if(five == 3):
              if(timerx[2]-timerx[0] > 1.5):
                timerx.pop(),timerx.pop(),timerx.pop()
                #too slow drop the rubbish
        if(five == 4):
              if(timerx[3]-timerx[0] > 2.25):
                timerx.pop(),timerx.pop(),timerx.pop(),timerx.pop()
                #too slow drop the rubbish  
        if(five == 5):  #selects menu page if 5 clicks in 2 seconds
            if(timerx[4]-timerx[0] < 3.0): #five clicks in 2 seconds
                if(Hnums != IRcommands[0] and Hnums != IRcommands[1] and
                   Hnums != IRcommands[2] and Hnums != IRcommands[3] and
                   Hnums != IRcommands[4]): #is it a select IR button                    
                       new_setupIR() #its not an OK select so get new set of IR commands
                       display_number[0] = 0 #only five clicks of OK for menu screen
                       raise_frame(groupframes[0]) #show                    
                       move_cursor(-100,0)
                       cursor_position[0] -=100 #move out of select area
                if (display_number[0] != 0 and Hnums != IRcommands[1] and
                    Hnums != IRcommands[2] and Hnums != IRcommands[3] and
                    Hnums != IRcommands[4]): #we may be on the menu screen
                        display_number[0] = 0 #only five clicks of OK for menu screen
                        raise_frame(groupframes[0]) #show                    
                        move_cursor(-100,0)
                        cursor_position[0] -=100 #move out of select area
                timerx.pop(),timerx.pop(),timerx.pop()
                timerx.pop(),timerx.pop() #get rid of it now
            else:
                timerx.pop(),timerx.pop(),timerx.pop(),timerx.pop(),timerx.pop()
                #too slow drop the rubbish


#called if IR command is recieved and selects a display page
def set_display_screen():
    sw,sh = screen_size
    spac = round((sh - 45)/8) #the space between buttons
    if(cursor_position[0] > 620): #in button area
        for n in range(0,8):
            if(cursor_position[1]>n*(spac+5) and cursor_position[1]<(n+1)*(spac+5)):
               display_number[0] = n #this display frame selected
               if(display_number[0] == 0): #sprecial case change IR commands
                   new_setupIR() #frame already displayed
               else:
                   raise_frame(groupframes[display_number[0]]) #show display frame

#called from set_display_screen or five if set IRcommands selected              
def new_setupIR():
    cv,OK,left,up,right,down,IR,cursor = menudisplays
    #delete existing set of IR commands
    IRcommands.pop(),IRcommands.pop(),IRcommands.pop(),IRcommands.pop(),IRcommands.pop()
    cv.itemconfigure(OK,fill = 'red')
    cv.itemconfigure(left,fill = 'grey')
    cv.itemconfigure(up,fill = 'grey')    #show the startup buttons
    cv.itemconfigure(right,fill = 'grey')
    cv.itemconfigure(down,fill = 'grey')            
    #done next IRcommand recieved goes to setupIR
    
#called on IRcommand recieved if IRcommands has not got full 5 buttons           
def setupIR(Hnums):
    cv,OK,left,up,right,down,IR,cursor = menudisplays
    key = len(IRcommands)
    if key < 5 :
        IRcommands.append(Hnums) #add this IRcommand button    
        if key == 0 :
            cv.itemconfigure(OK,fill = 'green')
            cv.itemconfigure(left,fill = 'red')
        if key == 1 :
            cv.itemconfigure(left,fill = 'green')
            cv.itemconfigure(up,fill = 'red')
        if key == 2 :
            cv.itemconfigure(up,fill = 'green')
            cv.itemconfigure(right,fill = 'red')
        if key == 3 :
            cv.itemconfigure(right,fill = 'green')
            cv.itemconfigure(down,fill = 'red')
        if key == 4 :
            cv.itemconfigure(down,fill = 'green')
            #save the commands in the weather folder. Write over existing
            Hnums = 'IR is set'
            with open(IRcommandsfile, 'w') as fn:
               fn.write(IRcommands[0]+'\n')
               fn.write(IRcommands[1]+'\n')
               fn.write(IRcommands[2]+'\n')
               fn.write(IRcommands[3]+'\n')
               fn.write(IRcommands[4]+'\n')
    if Hnums == 'IR is SET':  #show all green buttions
        cv.itemconfigure(OK,fill = 'green')
        cv.itemconfigure(left,fill = 'green')
        cv.itemconfigure(up,fill = 'green')
        cv.itemconfigure(right,fill = 'green')
        cv.itemconfigure(down,fill = 'green')
    cv.itemconfigure(IR,text = Hnums) #display the IR command

#cursor starts at nice location y set in create_menu
cursor_position=[530,0]
def move_cursor(posx,posy):
    cv,cursor = menudisplays[0],menudisplays[7]
    cv.move(cursor,posx,posy)
    cv.update()

#initialise BCM pin 18 to call interup routine Arduino_irq
def setup_pi_interupts():
    #irq pulled high when arduino has IR command  
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(18, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)   
    GPIO.add_event_detect(18, GPIO.RISING, callback=Arduino_irq)

#module access RTC at I2C address 0x68
ds3231 = SDL_DS3231.SDL_DS3231(1, 0x68)

#seperate thread for RTC runs whenever clock is being displayed
def run_thread(ct,timebox,monthbox,DAYday):
    t = Thread(target=display_clock, name = 'cd',args=(ct,timebox,monthbox,DAYday))
    t.daemon = True  #on completion the thread will be killed
    t.start()

#RTC is displayed in its own thread here
day = ('SUNDAY','MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY')
month = ('JANUARY','FEBURARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST',
         'SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER')    
def display_clock(ct,timebox,monthbox,DAYday):
    while True: #run always
        try:
            dt = ds3231.read_all()
            #Return tuple of year, month, date, day, hours, minutes, seconds.
        except ValueError: #problem in software ocasional error
            print('ds3231 soft error')
        else:   
            dtm ='{:02}'.format(dt[5])
            dth = dt[4]
            am = 'AM'  #only 12 hour clock
            if(dth > 12):
                    am = 'PM'
                    dth = dth - 12  #not 24 hour clock
            #show the current time data in previously created textboxs
            ct.itemconfigure(timebox,text=str(dth)+ ' : ' +str(dtm)+'  '+am)
            ct.itemconfigure(monthbox, text=month[dt[1]-1]+'   20'+str(dt[0]))
            ct.itemconfigure(DAYday, text=day[dt[3]-1]+ '   ' +str(dt[2]))
            time.sleep(15) #max error in display is 15 seconds   

#shows the currently displayed frame
def raise_frame(frame):
    frame.tkraise()
     #save the display_number[0] in the weather folder. Write over existing
    with open(displaynumberfile, 'w') as fn:
       fn.write(str(display_number[0]))

#add the 8 seperate frames on top of each other   
groupframes=[] #list of the 8 named frames
screen_size = [] #keep copy of the screen size
def set_frames(root):
    sw = root.winfo_screenwidth()
    screen_size.append(sw)
    sh = root.winfo_screenheight() #using the full screen
    screen_size.append(sh)
    set_IRcommands = Frame(root,bg='black') #groupframes[0]
    groupframes.append(set_IRcommands)
    display_current_data = Frame(root) #groupframes[1]
    groupframes.append(display_current_data)
    set_clock = Frame(root,bg='white') #groupframes[2]
    groupframes.append(set_clock)
    display_time = Frame(root,bg='white') #groupframes[3]
    groupframes.append(display_time)
    outdoorTH = Frame(root) #groupframes[4]
    groupframes.append(outdoorTH)
    indoorTH = Frame(root) #groupframes[5]
    groupframes.append(indoorTH)
    pressure_wind = Frame(root) #groupframes[6]
    groupframes.append(pressure_wind)
    lightning_rain = Frame(root) #groupframes[7]
    groupframes.append(lightning_rain)
    #lay each frame on top of each other
    for frame in (set_IRcommands,display_current_data,set_clock,display_time,
                  outdoorTH,indoorTH,pressure_wind,lightning_rain):
        frame.grid(row=0, column=0, sticky='news')    

#setup the displays on each of the seperate frames
menudisplays = []
#hold reference to menu objects [cv,OK,left,up,right,down,IR]
displaytimes = []
#hold reference to display clock[ct,time box,month box,day box]
def set_screens():
    sw,sh = screen_size

    (set_IRcommands,display_current_data,set_clock,display_time,outdoorTH,
                indoorTH,pressure_wind,lightning_rain) = groupframes
    #set IR_commands screen
    cv = Canvas(set_IRcommands,width=sw,height=sh,bg='black')
    cv.pack(side=LEFT) #set the canvas on LHS
    menudisplays.append(cv)
    create_menu() #setup all the controls on this page
    if len(IRcommands) == 5 :
        setupIR('IR is SET') #commands stored show the updated page
        
    #set display current data screen
    cc = Canvas(display_current_data,width=sw,height=sh,bg='black')
    cc.pack(side=LEFT) #set the canvas on LHS
    log.display_current_indoor(cc,sw,sh)
    log.display_current_outdoor(cc,sw,sh)
    log.display_pressure_lightning(cc,sw,sh)
    log.display_windspeed_rainfall(cc,sw,sh)
    
    #set set the clock screen
    cs = Canvas(set_clock,width=sw-12,height=sh-12,bg='black')
    cs.place(x=5,y=5)
    create_clockset(cs) #set up all the controls for clock set

    #set display the clock screen
    ct = Canvas(display_time,width=sw-12,height=sh-12,bg='black')
    ct.place(x=5,y=5)
    displaytimes.append(ct)
    time_textbox =ct.create_text((sw/2, 3*sh/4),fill='white',
                                 font=('Helvetica', '180'))
    displaytimes.append(time_textbox)
    month_textbox = ct.create_text((sw/2, 2*sh/6),fill='white',
                                   font=('Helvetica', '100'))
    displaytimes.append(month_textbox)
    DAYday_textbox = ct.create_text((sw/2, sh/6),fill='white',
                                    font=('Helvetica', '100'))
    displaytimes.append(DAYday_textbox)
    run_thread(ct,time_textbox,month_textbox,DAYday_textbox)
    #start clock thread. runs and users very little CPU time
    
    #set Outdoor temperature/humidity  screen
    co = Canvas(outdoorTH,width=sw,height=sh,bg='black')
    co.pack(side=LEFT) #set the canvas on LHS
    raffle_textbox = co.create_text((sw/2, sh/2),fill='white',
                        text=str(time.time()),font=('Helvetica', '50'))
  
    
    #set indoor temperature/humidity  screen
    Label(indoorTH, text='indoorTH', font=('Helvetica', '180')).pack()
    
    #set pressure and wind speed  screen
    Label(pressure_wind, text='press wind', font=('Helvetica', '180')).pack()
    
    #set lightning and rain screen
    Label(lightning_rain, text='light rain', font=('Helvetica', '180')).pack()
    
    raise_frame(groupframes[display_number[0]]) #first time raise current

#create the displays for the menu page    
def create_menu():
    cv = menudisplays[0]
    sw,sh = screen_size
    #x1,y1 to x2,y2
    OK = cv.create_oval((150, 150), (350, 350), fill='red')
    menudisplays.append(OK)
    cv.create_text((245, 250), text='OK',fill='white', font=('Helvetica', '80'))
    left = cv.create_polygon((0, 250), (150,  350), (150, 150),fill ='grey')
    menudisplays.append(left)
    up = cv.create_polygon((250, 0), (150,  150), (350, 150),fill = 'grey')
    menudisplays.append(up)
    right = cv.create_polygon((350, 150), (500,  250), (350, 350),fill = 'grey')
    menudisplays.append(right)
    down = cv.create_polygon((150, 350), (250,  500), (350, 350),fill = 'grey')
    menudisplays.append(down)
    cv.create_oval((140, 140), (360, 360),width=30, outline='black')

    txs = 25   #message text size
    mess1 = 'Register remote control buttons'
    mess2 = 'Select the RED button shown'
    mess3 = 'The curser can now be used'
    mess4 = 'Press OK 5 times for menu'
    cv.create_rectangle((5, 505), (495, sh-5), width=5,fill='white')
    cv.create_text((250, 510+txs), text=mess1,fill='black', font=('Helvetica', txs))
    cv.create_text((250, 510 + txs*3), text=mess2,fill='black', font=('Helvetica', txs))
    cv.create_text((250, 510+txs*5), text=mess3,fill='black', font=('Helvetica', txs)) 
    cv.create_text((250, 510+txs*7), text=mess4,fill='black', font=('Helvetica', txs))
    IR = cv.create_text((250, sh-100),fill='black', font=('Helvetica', 50))
    menudisplays.append(IR)
    
    spac = round((sh - 45)/8)
    bxs = 30  #button text size
    button =['Register remote buttons']
    button.append('Display real time data')
    button.append('Set the clock')
    button.append('Display the clock')
    button.append('Outdoor temperature/humidity')
    button.append('Indoor temperature/humidity')
    button.append('pressure and wind speed')
    button.append('lightning and rain')
    for n in range(0,8):
            cv.create_rectangle((600, n*(spac+5)+5), (sw-5, (n+1)*(spac+5)),
                                width=5,fill='white')
            cv.create_text((sw/2 + 300, 5*n+5+(2*n+1)*spac/2), text=button[n],fill='black',
                           font=('Helvetica', bxs))
    starty = sh/2 + round((sh - 45)/16) - 15
    cursor_position[1] = starty  #set initial y at nice place
    cursor = cv.create_polygon((0+530,0+starty),(40+530,20+starty),(40+530,40+starty),
                               (20+530,40+starty),fill = '#F308A1')
    menudisplays.append(cursor)

#create displays for the set clock page
time_values = []
#text boxs [year,month,date,day,hours,minutes,datetime,scursor,cs]
scursor_position = [0,0]
#the starting scursor index.move down to [7,0] move right to [0,1]
scursormovesize = [] #the step sizes for scursor [3*dx,2dy]
dtc = [] #the changed time values start with RTC
def create_clockset(cs):
    dt = ds3231.read_all()
    dtc.append(dt[0]),dtc.append(dt[1]),dtc.append(dt[2])
    dtc.append(dt[3]),dtc.append(dt[4]),dtc.append(dt[5]) 
    #Return tuple of year, month, date, day, hours, minutes, seconds.
    sw,sh = screen_size
    dx = round((sw-12)/21) #x box size
    scursormovesize.append(3*dx)
    dy = round((sh-12)/15) #y box size #based on a grid 21 x 17.2
    gx = round((sw-12)/102) #x gap size
    gy = round((sh-12)/86) #y gap size
    scursormovesize.append(2*dy+gy)
    mfs = 46
    sets = ['Set the year','Set the month','Set day of the month',
            'Set the day of the week','Set the hour','Set the minute']
    for n in range(0,6):
        cs.create_rectangle((gx, 2*n*dy+(n+1)*gy), (11*dx,2*dy*(n+1)+n*gy),
                            width=5,fill='white')
        cs.create_text((11*dx/2,2*n*dy+(n+1)*gy+dy-gy/2),text = sets[n],
                       fill = 'black', font=('Helvetica', mfs)) #set text buttons left
        cs.create_rectangle((11*dx+gx, 2*n*dy+(n+1)*gy), (14*dx, 2*dy*(n+1)+n*gy),
                            width=5,fill='black',outline = 'white') #current valu box
        value = cs.create_text(11*dx+gx + (14*dx - 11*dx-gx)/2,2*n*dy+(n+1)*
                               gy+dy-gy/2,text = dt[n],fill = 'white',
                               font=('Helvetica', mfs)) #text for current value boxes
        time_values.append(value) #add reference to all the text boxs
        cs.create_rectangle((15*dx+gx, 2*n*dy+(n+1)*gy), (18*dx, 2*dy*(n+1)+n*gy),
                            width=5,fill='white') #boxs for MORE text
        cs.create_text(15*dx+gx + 9*dx-(15*dx+gx)/2,2*n*dy+(n+1)*gy+dy-gy/2,
                       text ='MORE',fill = 'black', font=('Helvetica', mfs))
        cs.create_rectangle((18*dx+gx, 2*n*dy+(n+1)*gy), (sw-12-gx, 2*dy*(n+1)+n*gy),
                            width=5,fill='white') #boxs for LESS text
        cs.create_text(18*dx+gx + (sw-12-gx -18*dx-gx)/2,2*n*dy+(n+1)*gy+dy-gy/2,
                       text ='LESS',fill = 'black', font=('Helvetica', mfs))
    cs.create_rectangle((gx,2*6*dy+(6+1)*gy),(14*dx,sh-12-gy), width=5,
                        fill='black',outline = 'white') #current display text box
    dtm ='{:02}'.format(dt[5]) #get minutes as 05 for the date time text box
    datetime = cs.create_text(((14*dx+gx)/2,sh-12-dy),text=str(dt[4])+':'+dtm+'  '
                              +str(day[dt[3]-1])+' '+str(dt[2])+'/'+str(dt[1])+
                              '/20'+str(dt[0]),fill = 'white', font=('Helvetica', mfs))
    time_values.append(datetime)
    cs.create_rectangle((15*dx+gx,2*6*dy+(6+1)*gy),(sw-12-gx,sh-12-gy),
                        width=5,fill='white') #SET CLOCK box
    cs.create_text(((((sw-12-gx)-(15*dx+gx))/2)+(15*dx+gx),
                                2*6*dy+(6+1)*gy+dy-gy),text = 'SET CLOCK',
                               fill = 'black', font=('Helvetica', mfs))    
    scursor = cs.create_polygon((0+16*dx+gx,0+dy-gy),(40+16*dx+gx,20+dy-gy),
                                (40+16*dx+gx,40+dy-gy),(20+16*dx+gx,40+dy-gy),
                                fill = '#F308A1')
    time_values.append(scursor)
    time_values.append(cs) #have a reference to cs
    
#called on IR command received - if on the set clock screen
#the IR commands [OK,left,up,right,down]
def change_clock(Hnums) :
    cs = time_values[8]
    ddx,ddy = scursormovesize #scursor step size   
    if Hnums == IRcommands[3]: #move right not to far
        if scursor_position[0] == 0 :
            move_scursor(ddx,0)
            scursor_position[0] = 1
    if Hnums == IRcommands[1]: #move left not to far
        if scursor_position[0] == 1 :
            move_scursor(-ddx,0)
            scursor_position[0] = 0
    if Hnums == IRcommands[2]: #move up not to far
        if scursor_position[1] != 0 :
            move_scursor(0,-ddy)
            scursor_position[1] -= 1
    if Hnums == IRcommands[4]: #move down not to far
        if scursor_position[1] != 6 :
            move_scursor(0,ddy)
            scursor_position[1] += 1
    if Hnums == IRcommands[0]: #we have a selection
        if scursor_position[1] == 0 : #on the years
            if scursor_position[0] == 0: #MORE
                if dtc[0] < 99 : #max 99
                    dtc[0] +=1                
            else : #LESS
                if dtc[0] > 0: #min 0
                    dtc[0] -=1
        if scursor_position[1] == 1 : #on the months
            if scursor_position[0] == 0: #MORE
                if dtc[1] < 12 : #max 12
                    dtc[1] +=1                
            else : #LESS
                if dtc[1] > 1: #min 1
                    dtc[1] -=1
        if scursor_position[1] == 2 : #on the date
            if scursor_position[0] == 0: #MORE
                if dtc[2] < 31 : #max 31
                    dtc[2] +=1                
            else : #LESS
                if dtc[2] > 1: #min 1
                    dtc[2] -=1
        if scursor_position[1] == 3 : #on the day
            if scursor_position[0] == 0: #MORE
                if dtc[3] < 7 : #max 7
                    dtc[3] +=1                
            else : #LESS
                if dtc[3] > 1: #min 1
                    dtc[3] -=1
        if scursor_position[1] == 4 : #on the hour
            if scursor_position[0] == 0: #MORE
                if dtc[4] < 23 : #max 23
                    dtc[4] +=1                
            else : #LESS
                if dtc[4] > 1: #min 1
                    dtc[4] -=1
        if scursor_position[1] == 5 : #on the minute
            if scursor_position[0] == 0: #MORE
                if dtc[5] < 59 : #max 59
                    dtc[5] +=1                
            else : #LESS
                if dtc[5] > 1: #min 1
                    dtc[5] -=1
        if scursor_position[1] == 6 : #SET CLOCK
            ds3231.write_all(0,dtc[5],dtc[4],dtc[3],dtc[2],dtc[1],dtc[0])
            display_number[0] = 3
            raise_frame(groupframes[3]) #display the new clock
    for n in range(0,6) :
        cs.itemconfigure(time_values[n],text=str(dtc[n])) #display any updates
    dtm ='{:02}'.format(dtc[5]) #get minutes as 05 for the date time text box
    cs.itemconfigure(time_values[6],text = str(dtc[4])+':'+dtm+'  '+str(day[dtc[3]-1])
                     +' '+str(dtc[2])+'/'+str(dtc[1])+'/20'+str(dtc[0]))
    
#call to move clock set cursor            
def move_scursor(posx,posy):
    cs,scursor = time_values[8],time_values[7]
    cs.move(scursor,posx,posy)
    cs.update()
